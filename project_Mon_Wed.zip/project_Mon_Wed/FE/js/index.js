const $1 = document.querySelector.bind(document)
const $$ = document.querySelectorAll.bind(document)
const cart = $$('.widget_shopping')
const cart_empty = $1('.cart-empty')
const box_cart_items = $1('.nav-drop-box')
if(cart.length>0) {
    cart_empty.classList.remove('block')
    box_cart_items.classList.add('block')
}
$1('.logo-cart').innerHTML = cart.length